select * 
FROM "LN_31_60_Control_Group"